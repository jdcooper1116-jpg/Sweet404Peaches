#!/usr/bin/env bash
set -euo pipefail

if [ ! -f package.json ] || [ ! -d src/app ]; then
  echo "ERROR: Run this script from the Sweet404Peaches repo root." >&2
  exit 1
fi

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FILES_DIR="$PATCH_DIR/files"

if [ ! -d "$FILES_DIR" ]; then
  echo "ERROR: Missing files directory next to this script: $FILES_DIR" >&2
  exit 1
fi

echo "==> Creating/switching safety branch"
git checkout -b feature/engine-replay-backtesting 2>/dev/null || git checkout feature/engine-replay-backtesting

STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR=".backup_engine_replay_$STAMP"
mkdir -p "$BACKUP_DIR"

echo "==> Backing up current files to $BACKUP_DIR"
[ -f src/app/api/backtest/engine-replay/route.ts ] && mkdir -p "$BACKUP_DIR/src/app/api/backtest/engine-replay" && cp src/app/api/backtest/engine-replay/route.ts "$BACKUP_DIR/src/app/api/backtest/engine-replay/route.ts" || true
mkdir -p "$BACKUP_DIR/src/lib/firebase" "$BACKUP_DIR/src/app/backtesting/intake" "$BACKUP_DIR/src/app/backtesting/replay"
cp src/lib/firebase/firestore.ts "$BACKUP_DIR/src/lib/firebase/firestore.ts"
cp src/app/backtesting/intake/page.tsx "$BACKUP_DIR/src/app/backtesting/intake/page.tsx"
cp src/app/backtesting/replay/page.tsx "$BACKUP_DIR/src/app/backtesting/replay/page.tsx"

echo "==> Creating engine replay API route"
mkdir -p src/app/api/backtest/engine-replay
cp "$FILES_DIR/src/app/api/backtest/engine-replay/route.ts" src/app/api/backtest/engine-replay/route.ts

echo "==> Ensuring firestore.ts has required Firebase imports"
python3 - <<'PY'
from pathlib import Path
import re
path = Path('src/lib/firebase/firestore.ts')
text = path.read_text()
needed = ['Timestamp', 'writeBatch', 'doc', 'setDoc']
pattern = re.compile(r"import\s*\{(?P<body>.*?)\}\s*from\s*['\"]firebase/firestore['\"];", re.S)
match = pattern.search(text)
if match:
    body = match.group('body')
    existing = [x.strip() for x in body.replace('\n', ' ').split(',') if x.strip()]
    for name in needed:
        if name not in existing:
            existing.append(name)
    # Keep readable multiline import.
    new_import = "import {\n  " + ",\n  ".join(existing) + "\n} from 'firebase/firestore';"
    text = text[:match.start()] + new_import + text[match.end():]
else:
    insert = "import { Timestamp, writeBatch, doc, setDoc } from 'firebase/firestore';\n"
    text = insert + text
path.write_text(text)
PY

echo "==> Appending saveEngineReplayHits only if not already present"
if grep -q "export async function saveEngineReplayHits" src/lib/firebase/firestore.ts; then
  echo "saveEngineReplayHits already exists; skipping append."
else
  printf '\n\n' >> src/lib/firebase/firestore.ts
  cat "$FILES_DIR/src/lib/firebase/firestore_addition.ts" >> src/lib/firebase/firestore.ts
fi

echo "==> Replacing intake and replay pages"
cp "$FILES_DIR/src/app/backtesting/intake/page.tsx" src/app/backtesting/intake/page.tsx
cp "$FILES_DIR/src/app/backtesting/replay/page.tsx" src/app/backtesting/replay/page.tsx

echo "==> Verifying patch markers"
grep -n "Save & Run Engine Backtest\|handleSaveAndRunEngine" src/app/backtesting/intake/page.tsx | head || true
grep -n "Run via Engine\|handleRunEngineReplay" src/app/backtesting/replay/page.tsx | head || true
grep -n "export async function saveEngineReplayHits" src/lib/firebase/firestore.ts | head || true
grep -n "filters:        { match_mode: 'both' }\|normalizeCandidates\|function toHitType" src/app/api/backtest/engine-replay/route.ts | head || true

echo "==> Done. Now run: npm run build"
