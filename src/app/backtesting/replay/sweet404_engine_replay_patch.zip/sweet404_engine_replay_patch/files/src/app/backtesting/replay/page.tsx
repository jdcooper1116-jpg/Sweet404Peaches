'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import Sidebar from '@/components/layout/Sidebar';
import { useAuth } from '@/lib/contexts/AuthContext';
import {
  getBacktestDreamById,
  getBacktestSummaryForDream,
  listBacktestDreams,
  listBacktestHitsForDream,
  listBacktestResultsForDream,
  runBacktestReplayForDream,
  saveEngineReplayHits,
} from '@/lib/firebase/firestore';

export default function BacktestingReplayPage() {
  const { user } = useAuth();

  const [dreams,             setDreams]             = useState<any[]>([]);
  const [selectedBacktestId, setSelectedBacktestId] = useState('');
  const [running,            setRunning]             = useState(false);
  const [runningEngine,      setRunningEngine]       = useState(false);
  const [loadingDreams,      setLoadingDreams]       = useState(true);
  const [loadingReplayData,  setLoadingReplayData]   = useState(true);
  const [savedResults,       setSavedResults]        = useState<any[]>([]);
  const [hits,               setHits]                = useState<any[]>([]);
  const [summary,            setSummary]             = useState<any | null>(null);
  const [message,            setMessage]             = useState('');
  const [error,              setError]               = useState('');

  useEffect(() => {
    async function loadDreams() {
      if (!user) { setDreams([]); setLoadingDreams(false); return; }
      try {
        const rows = await listBacktestDreams(user.uid);
        setDreams(rows);
        if (rows.length) {
          setSelectedBacktestId((current) => current || rows[0].id);
        }
      } catch (err) {
        console.error(err);
        setError('Could not load backtest dreams.');
      } finally {
        setLoadingDreams(false);
      }
    }
    void loadDreams();
  }, [user]);

  useEffect(() => {
    async function loadReplayData() {
      if (!user || !selectedBacktestId) {
        setSavedResults([]); setHits([]); setSummary(null);
        setLoadingReplayData(false);
        return;
      }
      setLoadingReplayData(true);
      try {
        const [resultsRows, hitRows, summaryRow] = await Promise.all([
          listBacktestResultsForDream(user.uid, selectedBacktestId),
          listBacktestHitsForDream(user.uid, selectedBacktestId),
          getBacktestSummaryForDream(user.uid, selectedBacktestId),
        ]);
        setSavedResults(resultsRows);
        setHits(hitRows);
        setSummary(summaryRow);
      } catch (err) {
        console.error(err);
      } finally {
        setLoadingReplayData(false);
      }
    }
    void loadReplayData();
  }, [user, selectedBacktestId]);

  const selectedDream = useMemo(
    () => dreams.find((d) => d.id === selectedBacktestId) ?? null,
    [dreams, selectedBacktestId]
  );

  // ── Manual replay (existing — unchanged) ─────────────────────────────────────
  async function handleRunReplay() {
    if (!user)               { setError('You must be signed in.');           return; }
    if (!selectedBacktestId) { setError('Please select a backtest dream.');  return; }

    setRunning(true);
    setError('');
    setMessage('');

    try {
      const summaryRow = await runBacktestReplayForDream(user.uid, selectedBacktestId);
      const hitRows    = await listBacktestHitsForDream(user.uid, selectedBacktestId);
      setSummary(summaryRow);
      setHits(hitRows);
      setMessage(
        `Manual replay complete. ${summaryRow.totalHits ?? 0} hit(s) detected and dictionaries strengthened.`
      );
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Could not run manual replay.');
    } finally {
      setRunning(false);
    }
  }

  // ── Engine replay (new) ───────────────────────────────────────────────────────
  async function handleRunEngineReplay() {
    if (!user)               { setError('You must be signed in.');           return; }
    if (!selectedBacktestId) { setError('Please select a backtest dream.');  return; }
    if (!selectedDream)      { setError('Could not load selected dream.');   return; }

    setRunningEngine(true);
    setError('');
    setMessage('Querying lottery engine across all states…');

    try {
      const res = await fetch('/api/backtest/engine-replay', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          backtestDreamId:    selectedBacktestId,
          dreamDate:          selectedDream.dreamDate,
          lookaheadDays:      7,
          cash3Numbers:       selectedDream.cash3Numbers       ?? [],
          cash4Numbers:       selectedDream.cash4Numbers       ?? [],
          parsedTermMappings: selectedDream.parsedTermMappings ?? [],
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || 'Engine replay request failed.');
      }

      // Persist hits to Firestore
      await saveEngineReplayHits(
        user.uid,
        selectedBacktestId,
        selectedDream.dreamDate,
        data.hits ?? []
      );

      // Reload display
      const [hitRows, summaryRow] = await Promise.all([
        listBacktestHitsForDream(user.uid, selectedBacktestId),
        getBacktestSummaryForDream(user.uid, selectedBacktestId),
      ]);
      setHits(hitRows);
      setSummary(summaryRow);

      const errCount = data.errors?.length ?? 0;
      setMessage(
        `✓ Engine replay complete. ` +
        `${data.totalHits} hit(s) — ${data.straightHits} straight, ${data.boxedHits} boxed — ` +
        `across ${data.uniqueStates?.length ?? 0} state(s).` +
        (data.bestState ? ` Best state: ${data.bestState}.` : '') +
        (errCount > 0 ? ` (${errCount} state(s) failed — see engine logs.)` : '')
      );
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Engine replay failed.');
    } finally {
      setRunningEngine(false);
    }
  }

  const isEngineReplayed = selectedDream?.status === 'engine-replay-complete';
  const hasManualResults  = savedResults.length > 0;

  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'grid',
        gridTemplateColumns: '280px 1fr',
        background:
          'radial-gradient(circle at top left, rgba(228,192,123,0.14), transparent 18%), radial-gradient(circle at top right, rgba(108,120,255,0.12), transparent 22%), linear-gradient(135deg, #1A1A2E 0%, #16213E 48%, #0F3460 100%)',
      }}
    >
      <Sidebar />

      <section style={{ padding: '32px', display: 'grid', gap: '24px' }}>
        {/* Header */}
        <section className="journal-card">
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: '16px',
              alignItems: 'flex-start',
              flexWrap: 'wrap',
            }}
          >
            <div className="page-header">
              <h1>Replay Lab</h1>
              <p>
                Re-run historical backtests for any saved dream.
                <strong> Run via Engine</strong> queries the lottery engine across all states automatically.
                <strong> Run via Saved Results</strong> uses manually uploaded result rows (legacy path).
              </p>
            </div>

            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <Link href="/backtesting/intake"  className="btn-secondary">Historical Dream Intake</Link>
              <Link href="/backtesting/archive" className="btn-secondary">Backtest Archive</Link>
              <Link href="/fell-before"         className="btn-secondary">As They Fell Before</Link>
            </div>
          </div>
        </section>

        {/* Dream selector */}
        <section
          className="journal-card"
          style={{ display: 'grid', gap: '16px', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))' }}
        >
          <div>
            <label className="journal-label" htmlFor="backtestDream">Select Backtest Dream</label>
            <select
              id="backtestDream"
              className="journal-select"
              value={selectedBacktestId}
              onChange={(e) => setSelectedBacktestId(e.target.value)}
              disabled={loadingDreams}
            >
              <option value="">Choose a saved backtest dream</option>
              {dreams.map((dream) => (
                <option key={dream.id} value={dream.id}>
                  {dream.dreamDate || 'No Date'} · {dream.source || 'unknown'} · {dream.status || '—'}
                </option>
              ))}
            </select>
          </div>

          <div className="journal-card-flat">
            <div className="journal-label">Window</div>
            <div style={{ marginTop: '8px', color: 'var(--ink-light)' }}>
              {selectedDream
                ? `${selectedDream.activeWindowStart || '—'} → ${selectedDream.activeWindowEnd || '—'}`
                : 'Select a dream to view its window.'}
            </div>
          </div>

          <div className="journal-card-flat">
            <div className="journal-label">Current Status</div>
            <div style={{
              marginTop: '8px',
              fontWeight: 700,
              color: isEngineReplayed ? '#6dbf8a'
                : selectedDream?.status === 'replay-complete' ? '#d4a95a'
                : 'var(--ink-light)',
            }}>
              {selectedDream?.status || '—'}
            </div>
          </div>

          {selectedDream && (
            <div className="journal-card-flat">
              <div className="journal-label">Candidates</div>
              <div style={{ marginTop: '8px', fontSize: '0.82rem', color: 'var(--ink-light)' }}>
                Pick 3: {selectedDream.cash3Numbers?.length ?? 0} · Pick 4: {selectedDream.cash4Numbers?.length ?? 0}
              </div>
            </div>
          )}
        </section>

        {/* Messages */}
        {message && (
          <section className="journal-card-flat" style={{ borderColor: '#cfe5c8', background: '#f5fbf2', color: '#315a2b' }}>
            {message}
          </section>
        )}
        {error && (
          <section className="journal-card-flat" style={{ borderColor: '#e9c2c2', background: '#fff4f4', color: '#8a2f2f' }}>
            {error}
          </section>
        )}

        {/* Action buttons */}
        <section className="journal-card">
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center' }}>

            {/* Primary: engine replay */}
            <button
              type="button"
              className="btn-primary"
              onClick={handleRunEngineReplay}
              disabled={runningEngine || running || !selectedBacktestId}
            >
              {runningEngine ? 'Querying engine across all states…' : '⚡ Run via Engine'}
            </button>

            {/* Secondary: manual replay (requires uploaded results) */}
            <button
              type="button"
              className="btn-secondary"
              onClick={handleRunReplay}
              disabled={running || runningEngine || !selectedBacktestId || !hasManualResults}
              title={!hasManualResults ? 'Upload results in Historical Results Intake first' : ''}
              style={{ opacity: !hasManualResults ? 0.45 : 1, cursor: !hasManualResults ? 'not-allowed' : 'pointer' }}
            >
              {running ? 'Running…' : 'Run via Saved Results'}
            </button>

            {!hasManualResults && selectedBacktestId && (
              <span style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.35)' }}>
                No manual results uploaded — use engine path above.
              </span>
            )}
          </div>
        </section>

        {/* Stats bar */}
        <section
          className="journal-card-flat"
          style={{ display: 'grid', gap: '12px', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))' }}
        >
          <div>
            <div className="journal-label">Manual Results Loaded</div>
            <div style={{ fontSize: '28px', fontWeight: 700 }}>{savedResults.length}</div>
          </div>
          <div>
            <div className="journal-label">Backtest Hits</div>
            <div style={{ fontSize: '28px', fontWeight: 700 }}>{hits.length}</div>
          </div>
          <div>
            <div className="journal-label">Straight Hits</div>
            <div style={{ fontSize: '28px', fontWeight: 700 }}>{summary?.straightHits ?? 0}</div>
          </div>
          <div>
            <div className="journal-label">Boxed Hits</div>
            <div style={{ fontSize: '28px', fontWeight: 700 }}>{summary?.boxedHits ?? 0}</div>
          </div>
          {summary?.replaySource && (
            <div>
              <div className="journal-label">Replay Source</div>
              <div style={{ fontSize: '0.85rem', fontWeight: 600, color: summary.replaySource === 'lottery-engine' ? '#6dbf8a' : '#d4a95a' }}>
                {summary.replaySource === 'lottery-engine' ? '⚡ Lottery Engine' : 'Manual Upload'}
              </div>
            </div>
          )}
        </section>

        {/* Replay Summary */}
        <section className="journal-card">
          <div className="page-header">
            <h1>Replay Summary</h1>
            <p>Updates after running either replay path.</p>
          </div>

          {loadingReplayData ? (
            <p>Loading replay summary...</p>
          ) : summary ? (
            <div
              style={{
                display: 'grid',
                gap: '12px',
                gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                marginTop: '12px',
              }}
            >
              <div className="journal-card-flat"><div className="journal-label">Total Hits</div><div>{summary.totalHits ?? 0}</div></div>
              <div className="journal-card-flat"><div className="journal-label">Straight Hits</div><div>{summary.straightHits ?? 0}</div></div>
              <div className="journal-card-flat"><div className="journal-label">Boxed Hits</div><div>{summary.boxedHits ?? 0}</div></div>
              <div className="journal-card-flat"><div className="journal-label">Best State</div><div>{summary.bestState || '—'}</div></div>
              <div className="journal-card-flat"><div className="journal-label">Best Term</div><div>{summary.bestTerm || '—'}</div></div>
              <div className="journal-card-flat">
                <div className="journal-label">States With Hits</div>
                <div>{Array.isArray(summary.uniqueStates) ? summary.uniqueStates.length : 0}</div>
              </div>
            </div>
          ) : (
            <p>No replay summary yet.</p>
          )}
        </section>

        {/* Detected hits */}
        <section className="journal-card">
          <div className="page-header">
            <h1>Detected Historical Hits</h1>
            <p>All hits detected for the selected dream, sorted chronologically.</p>
          </div>

          {loadingReplayData ? (
            <p>Loading backtest hits...</p>
          ) : hits.length ? (
            <div style={{ display: 'grid', gap: '12px', marginTop: '12px' }}>
              {hits.map((hit) => (
                <div key={hit.id} className="journal-card-flat"
                  style={{ borderLeft: `3px solid ${hit.hitType === 'straight' ? '#4a7c59' : '#a07c4a'}` }}
                >
                  <div style={{ display: 'grid', gap: '8px', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))' }}>
                    <div><strong>Term:</strong> {hit.termLabel}</div>
                    <div><strong>Number:</strong> {hit.number}</div>
                    <div><strong>State:</strong> {hit.state}</div>
                    <div><strong>Game:</strong> {hit.gameType}</div>
                    <div><strong>Draw:</strong> {hit.drawTime}</div>
                    <div><strong>Date:</strong> {hit.drawDate}</div>
                    <div>
                      <strong>Hit Type:</strong>{' '}
                      <span style={{ color: hit.hitType === 'straight' ? '#6dbf8a' : '#d4a95a', fontWeight: 700 }}>
                        {hit.hitType === 'straight' ? '⬛ Straight' : '◻ Boxed'}
                      </span>
                    </div>
                    <div><strong>Result:</strong> {hit.normalizedResult}</div>
                    <div><strong>Days From Dream:</strong> {hit.daysFromDream}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>No backtest hits detected yet.</p>
          )}
        </section>
      </section>
    </main>
  );
}
