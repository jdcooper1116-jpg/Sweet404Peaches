import { NextRequest, NextResponse } from 'next/server';

// Allow enough time for two all-states fan-outs (pick3 + pick4).
export const maxDuration = 60;

// ─── Types ────────────────────────────────────────────────────────────────────

interface ParsedTermMapping {
  term: string;
  cash3Numbers: string[];
  cash4Numbers: string[];
  [key: string]: unknown;
}

interface EngineAllStatesHit {
  candidate:      string;
  draw_date:      string;
  draw_time:      string;
  winning_number: string;
  match_type:     string;
  state:          string;
  is_verified?:   boolean;
  source_name?:   string;
}

export interface MappedBacktestHit {
  termLabel:       string;
  number:          string;
  gameType:        'cash3' | 'cash4';
  state:           string;
  drawDate:        string;
  drawTime:        string;
  rawResult:       string;
  normalizedResult: string;
  resultBoxedKey:  string;
  hitType:         'straight' | 'boxed';
  daysFromDream:   number;
  sameDay:         boolean;
  match_type:      string;
  is_verified:     boolean;
  source_name:     string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function sortedDigits(value: string): string {
  return value.split('').sort().join('');
}

function normalizeCandidates(values: unknown[], length: number): string[] {
  const cleaned = values
    .map(v => String(v ?? '').replace(/\D/g, ''))
    .filter(v => v.length === length);

  return Array.from(new Set(cleaned));
}

function daysBetween(start: string, end: string): number {
  const startMs = new Date(`${start}T00:00:00`).getTime();
  const endMs   = new Date(`${end}T00:00:00`).getTime();
  return Math.max(0, Math.floor((endMs - startMs) / 86_400_000));
}

/**
 * Find the dream term associated with a candidate number.
 * Searches parsedTermMappings for the first mapping whose
 * cash3Numbers or cash4Numbers array contains the candidate.
 */
function findTermLabel(
  candidate:          string,
  parsedTermMappings: ParsedTermMapping[],
  numberKey:          'cash3Numbers' | 'cash4Numbers'
): string {
  for (const mapping of parsedTermMappings) {
    const nums = Array.isArray(mapping[numberKey]) ? mapping[numberKey] : [];
    if (nums.includes(candidate)) {
      return String(mapping.term || 'unknown-term');
    }
  }
  return 'unknown-term';
}

/**
 * Engine match_type → Firestore hitType.
 * "exact" = straight (digit-for-digit). Everything else = boxed.
 */
function toHitType(candidate: string, winning: string): 'straight' | 'boxed' {
  return String(candidate) === String(winning) ? 'straight' : 'boxed';
}

/**
 * Map raw engine combined_hits → MappedBacktestHit array
 * ready to be written to Firestore backtestHits.
 */
function mapEngineHits(
  hits:               EngineAllStatesHit[],
  dreamDate:          string,
  gameType:           'cash3' | 'cash4',
  numberKey:          'cash3Numbers' | 'cash4Numbers',
  parsedTermMappings: ParsedTermMapping[]
): MappedBacktestHit[] {
  return hits.map(hit => {
    const days = daysBetween(dreamDate, hit.draw_date);
    return {
      termLabel:        findTermLabel(hit.candidate, parsedTermMappings, numberKey),
      number:           hit.candidate,
      gameType,
      state:            hit.state ?? '',
      drawDate:         hit.draw_date,
      drawTime:         hit.draw_time,
      rawResult:        hit.winning_number,
      normalizedResult: hit.winning_number,
      resultBoxedKey:   sortedDigits(hit.winning_number),
      hitType:          toHitType(hit.candidate, hit.winning_number),
      daysFromDream:    days,
      sameDay:          days === 0,
      match_type:       hit.match_type,
      is_verified:      hit.is_verified ?? false,
      source_name:      hit.source_name ?? '',
    };
  });
}

/**
 * Call the Sweet404Peaches all-states bridge (/api/backtest)
 * for one game type and return mapped hits.
 * Returns [] on any error — errors are collected separately.
 */
async function callEngineForGameType(
  baseUrl:            string,
  dreamDate:          string,
  lookaheadDays:      number,
  candidates:         string[],
  gameType:           'pick3' | 'pick4',
  firestoreGameType:  'cash3' | 'cash4',
  numberKey:          'cash3Numbers' | 'cash4Numbers',
  parsedTermMappings: ParsedTermMapping[],
  label:              string,
  errors:             string[]
): Promise<MappedBacktestHit[]> {
  if (!candidates.length) return [];

  try {
    const res = await fetch(`${baseUrl}/api/backtest`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        scope:          'all-states',
        state:          'ALL',
        game_type:      gameType,
        anchor_date:    dreamDate,
        lookahead_days: lookaheadDays,
        candidates,
        mode:           'both',
        match_mode:     'both',
        filters:        { match_mode: 'both' },
        label,
      }),
    });

    if (!res.ok) {
      errors.push(`${gameType} engine call failed: HTTP ${res.status}`);
      return [];
    }

    const data = await res.json();
    const rawHits: EngineAllStatesHit[] = Array.isArray(data.combined_hits)
      ? data.combined_hits
      : Array.isArray(data.hits)
        ? data.hits
        : [];

    return mapEngineHits(rawHits, dreamDate, firestoreGameType, numberKey, parsedTermMappings);
  } catch (err) {
    errors.push(
      `${gameType} engine call error: ${err instanceof Error ? err.message : String(err)}`
    );
    return [];
  }
}

// ─── Route handler ────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  const {
    backtestDreamId,
    dreamDate,
    lookaheadDays = 7,
    cash3Numbers     = [],
    cash4Numbers     = [],
    parsedTermMappings = [],
  } = body as {
    backtestDreamId:    string;
    dreamDate:          string;
    lookaheadDays?:     number;
    cash3Numbers?:      string[];
    cash4Numbers?:      string[];
    parsedTermMappings?: ParsedTermMapping[];
  };

  if (!backtestDreamId) {
    return NextResponse.json({ error: 'backtestDreamId is required.' }, { status: 400 });
  }
  if (!dreamDate) {
    return NextResponse.json({ error: 'dreamDate is required.' }, { status: 400 });
  }

  const baseUrl  = req.nextUrl.origin;
  const label    = `engine-replay::${backtestDreamId}`;
  const mappings = Array.isArray(parsedTermMappings) ? parsedTermMappings as ParsedTermMapping[] : [];
  const errors:  string[] = [];

  // Run pick3 and pick4 in parallel.
  const [pick3Hits, pick4Hits] = await Promise.all([
    callEngineForGameType(
      baseUrl, dreamDate, Number(lookaheadDays),
      normalizeCandidates(Array.isArray(cash3Numbers) ? cash3Numbers : [], 3),
      'pick3', 'cash3', 'cash3Numbers', mappings, label, errors
    ),
    callEngineForGameType(
      baseUrl, dreamDate, Number(lookaheadDays),
      normalizeCandidates(Array.isArray(cash4Numbers) ? cash4Numbers : [], 4),
      'pick4', 'cash4', 'cash4Numbers', mappings, label, errors
    ),
  ]);

  const allHits = [...pick3Hits, ...pick4Hits];

  // Sort chronologically for display.
  allHits.sort((a, b) => {
    const ak = `${a.drawDate} ${a.drawTime}`;
    const bk = `${b.drawDate} ${b.drawTime}`;
    return ak < bk ? -1 : ak > bk ? 1 : 0;
  });

  // Build summary stats.
  const straightHits = allHits.filter(h => h.hitType === 'straight').length;
  const boxedHits    = allHits.filter(h => h.hitType === 'boxed').length;

  const stateCounts = new Map<string, number>();
  const termCounts  = new Map<string, number>();
  for (const hit of allHits) {
    stateCounts.set(hit.state,     (stateCounts.get(hit.state)     ?? 0) + 1);
    termCounts.set(hit.termLabel,  (termCounts.get(hit.termLabel)  ?? 0) + 1);
  }

  const uniqueStates = Array.from(stateCounts.keys());
  const bestState    = Array.from(stateCounts.entries()).sort((a, b) => b[1] - a[1])[0]?.[0] ?? '';
  const bestTerm     = Array.from(termCounts.entries()).sort((a, b) => b[1] - a[1])[0]?.[0] ?? '';

  return NextResponse.json({
    ok:             true,
    backtestDreamId,
    dreamDate,
    lookaheadDays:  Number(lookaheadDays),
    totalHits:      allHits.length,
    straightHits,
    boxedHits,
    uniqueStates,
    bestState,
    bestTerm,
    hits:           allHits,
    errors,
  });
}
