'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { BookOpenText, Sparkles } from 'lucide-react';
import Sidebar from '@/components/layout/Sidebar';
import { useAuth } from '@/lib/contexts/AuthContext';
import {
  createBacktestDreamIntake,
  listBacktestDreams,
  saveEngineReplayHits,
  upsertOwnerProfile,
} from '@/lib/firebase/firestore';
import { parseDreamText } from '@/lib/parser/dreamParser';
import type { ParseResult } from '@/lib/types';

function addDays(dateString: string, days: number) {
  const d = new Date(`${dateString}T00:00:00`);
  if (Number.isNaN(d.getTime())) return '';
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export default function BacktestingIntakePage() {
  const { user } = useAuth();

  const [dreamDate,      setDreamDate]      = useState('');
  const [dreamSource,    setDreamSource]    = useState('handwritten-journal');
  const [confidence,     setConfidence]     = useState('high');
  const [dreamText,      setDreamText]      = useState('');
  const [notes,          setNotes]          = useState('');

  const [parseResult,    setParseResult]    = useState<ParseResult | null>(null);
  const [saving,         setSaving]         = useState(false);
  const [runningEngine,  setRunningEngine]  = useState(false);
  const [loadingRecent,  setLoadingRecent]  = useState(true);
  const [message,        setMessage]        = useState('');
  const [error,          setError]          = useState('');
  const [recentBacktests, setRecentBacktests] = useState<any[]>([]);

  const windowStart = dreamDate || '—';
  const windowEnd   = useMemo(() => (dreamDate ? addDays(dreamDate, 6) : '—'), [dreamDate]);

  useEffect(() => {
    async function loadRecent() {
      if (!user) { setRecentBacktests([]); setLoadingRecent(false); return; }
      try {
        const rows = await listBacktestDreams(user.uid);
        setRecentBacktests(rows);
      } catch (err) {
        console.error(err);
      } finally {
        setLoadingRecent(false);
      }
    }
    void loadRecent();
  }, [user]);

  function handleParseDream() {
    if (!dreamText.trim()) {
      setError('Please paste the historical dream text first.');
      setParseResult(null);
      return;
    }
    setError('');
    setMessage('');
    setParseResult(parseDreamText(dreamText));
  }

  // ── Core save — returns backtestDreamId on success, null on failure ──────────
  async function coreSave(): Promise<string | null> {
    if (!user)             { setError('You must be signed in.');                          return null; }
    if (!dreamDate)        { setError('Please choose the original dream date.');           return null; }
    if (!dreamText.trim()) { setError('Please paste the historical dream text.');          return null; }
    if (!parseResult)      { setError('Please parse the dream before saving it.');         return null; }

    setSaving(true);
    setError('');
    setMessage('');

    try {
      await upsertOwnerProfile(user.uid, {
        displayName: user.displayName || 'Sweet404Peaches',
        email:       user.email || '',
      });

      const backtestDreamId = await createBacktestDreamIntake(user.uid, {
        dreamDate,
        rawText:    dreamText,
        source:     dreamSource,
        confidence,
        notes,
        parseResult,
      });

      const refreshed = await listBacktestDreams(user.uid);
      setRecentBacktests(refreshed);
      return backtestDreamId;
    } catch (err) {
      console.error(err);
      setError('Could not save the historical dream intake.');
      return null;
    } finally {
      setSaving(false);
    }
  }

  // ── Save only (original button) ───────────────────────────────────────────────
  async function handleSaveBacktestDream() {
    const id = await coreSave();
    if (!id) return;
    setMessage(
      `Backtest dream saved. ID: ${id}. ` +
      `Parsed evidence was added to the Universal Dream Dictionary and a 7-day research window was created. ` +
      `Click "Save & Run Engine Backtest" to auto-detect hits from the lottery engine.`
    );
    setDreamText('');
    setNotes('');
    setParseResult(null);
  }

  // ── Save + run engine replay ──────────────────────────────────────────────────
  async function handleSaveAndRunEngine() {
    const id = await coreSave();
    if (!id) return;

    setRunningEngine(true);
    setMessage('Dream saved. Running engine backtest across all states…');

    try {
      const res = await fetch('/api/backtest/engine-replay', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          backtestDreamId:    id,
          dreamDate,
          lookaheadDays:      7,
          cash3Numbers:       parseResult?.cash3Numbers  ?? [],
          cash4Numbers:       parseResult?.cash4Numbers  ?? [],
          parsedTermMappings: parseResult?.termMappings  ?? [],
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || 'Engine replay request failed.');
      }

      // Persist hits to Firestore
      if (Array.isArray(data.hits) && data.hits.length > 0) {
        await saveEngineReplayHits(user!.uid, id, dreamDate, data.hits);
      } else {
        // Still update status even with zero hits
        await saveEngineReplayHits(user!.uid, id, dreamDate, []);
      }

      const stateCount = data.uniqueStates?.length ?? 0;
      const errCount   = data.errors?.length ?? 0;

      setMessage(
        `✓ Saved & engine replay complete. ` +
        `${data.totalHits} hit(s) found — ` +
        `${data.straightHits} straight, ${data.boxedHits} boxed — ` +
        `across ${stateCount} state(s).` +
        (data.bestState ? ` Best state: ${data.bestState}.` : '') +
        (errCount > 0 ? ` (${errCount} state(s) failed — check Replay Lab for details.)` : '') +
        ` View full results in the Replay Lab or Backtest Archive.`
      );

      setDreamText('');
      setNotes('');
      setParseResult(null);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Engine replay failed after save.');
    } finally {
      setRunningEngine(false);
    }
  }

  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'grid',
        gridTemplateColumns: '280px 1fr',
        background:
          'radial-gradient(circle at top left, rgba(228,192,123,0.14), transparent 18%), radial-gradient(circle at top right, rgba(108,120,255,0.12), transparent 22%), linear-gradient(135deg, #1A1A2E 0%, #16213E 48%, #0F3460 100%)',
      }}
    >
      <Sidebar />

      <section style={{ padding: '32px', display: 'grid', gap: '24px' }}>
        <section className="journal-card">
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: '16px',
              alignItems: 'flex-start',
              flexWrap: 'wrap',
            }}
          >
            <div className="page-header">
              <h1>Historical Dream Intake</h1>
              <p>
                Paste an old dream, parse it, and save it into Research Mode.
                Use <strong>Save &amp; Run Engine Backtest</strong> to automatically detect
                hits across all states via the lottery engine — no manual results upload needed.
              </p>
            </div>

            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <Link href="/backtesting"         className="btn-secondary">Backtesting Portal</Link>
              <Link href="/backtesting/archive" className="btn-secondary">Backtest Archive</Link>
              <Link href="/backtesting/replay"  className="btn-secondary">Replay Lab</Link>
            </div>
          </div>
        </section>

        <section
          className="journal-card"
          style={{
            display: 'grid',
            gap: '16px',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          }}
        >
          <div>
            <label className="journal-label" htmlFor="dreamDate">Original Dream Date</label>
            <input
              id="dreamDate"
              type="date"
              className="journal-input"
              value={dreamDate}
              onChange={(e) => setDreamDate(e.target.value)}
            />
          </div>

          <div>
            <label className="journal-label" htmlFor="dreamSource">Source</label>
            <select
              id="dreamSource"
              className="journal-select"
              value={dreamSource}
              onChange={(e) => setDreamSource(e.target.value)}
            >
              <option value="handwritten-journal">Handwritten Journal</option>
              <option value="notes-app">Notes App</option>
              <option value="text-message">Text Message</option>
              <option value="memory-reconstruction">Memory Reconstruction</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label className="journal-label" htmlFor="confidence">Transcription Confidence</label>
            <select
              id="confidence"
              className="journal-select"
              value={confidence}
              onChange={(e) => setConfidence(e.target.value)}
            >
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </section>

        <section className="journal-card">
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '18px',
              color: 'var(--deep-plum)',
            }}
          >
            <BookOpenText size={20} />
            <strong>Historical Dream Intake</strong>
          </div>

          <div style={{ display: 'grid', gap: '18px' }}>
            <div>
              <label className="journal-label" htmlFor="dreamText">Historical Dream Text</label>
              <textarea
                id="dreamText"
                className="journal-textarea"
                rows={16}
                value={dreamText}
                onChange={(e) => setDreamText(e.target.value)}
                placeholder="Paste the historical dream exactly as recorded..."
              />
            </div>

            <div>
              <label className="journal-label" htmlFor="notes">Research Notes</label>
              <textarea
                id="notes"
                className="journal-textarea"
                rows={6}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Optional notes about this dream, context, confidence, or why it matters..."
              />
            </div>

            {message && (
              <div className="journal-card-flat" style={{ borderColor: '#cfe5c8', background: '#f5fbf2', color: '#315a2b' }}>
                {message}
              </div>
            )}

            {error && (
              <div className="journal-card-flat" style={{ borderColor: '#e9c2c2', background: '#fff4f4', color: '#8a2f2f' }}>
                {error}
              </div>
            )}

            <div className="journal-card-flat" style={{ display: 'grid', gap: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--deep-plum)' }}>
                <Sparkles size={16} />
                <strong>Research Evidence Flow</strong>
              </div>
              <p style={{ margin: 0, fontSize: '14px', color: 'var(--ink-light)', lineHeight: 1.6 }}>
                <strong>Save Dream</strong> — saves parsed terms to the Universal Dictionary, creates a 7-day research window. You then manually attach results and run replay.<br />
                <strong>Save &amp; Run Engine Backtest</strong> — does all of the above, then automatically queries the lottery engine across all states and saves any hits directly. No manual results upload needed.
              </p>
            </div>

            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <button
                type="button"
                className="btn-secondary"
                onClick={handleParseDream}
                disabled={saving || runningEngine}
              >
                Parse Historical Dream
              </button>

              <button
                type="button"
                className="btn-secondary"
                onClick={handleSaveBacktestDream}
                disabled={saving || runningEngine}
              >
                {saving ? 'Saving…' : 'Save Dream Only'}
              </button>

              <button
                type="button"
                className="btn-primary"
                onClick={handleSaveAndRunEngine}
                disabled={saving || runningEngine || !parseResult}
                style={{
                  opacity: !parseResult ? 0.55 : 1,
                  cursor: !parseResult ? 'not-allowed' : 'pointer',
                }}
              >
                {runningEngine
                  ? 'Running engine across all states…'
                  : 'Save & Run Engine Backtest'}
              </button>
            </div>

            {!parseResult && (
              <p style={{ margin: 0, fontSize: '0.78rem', color: 'rgba(255,255,255,0.35)' }}>
                Parse the dream first to enable the engine backtest button.
              </p>
            )}
          </div>
        </section>

        <section
          className="journal-card-flat"
          style={{
            display: 'grid',
            gap: '12px',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          }}
        >
          <div>
            <div className="journal-label">Backtest Window Start</div>
            <div style={{ fontWeight: 700 }}>{windowStart}</div>
          </div>
          <div>
            <div className="journal-label">Backtest Window End</div>
            <div style={{ fontWeight: 700 }}>{windowEnd}</div>
          </div>
          <div>
            <div className="journal-label">Engine Coverage</div>
            <div style={{ fontWeight: 700 }}>All States · Pick 3 + Pick 4</div>
          </div>
          <div>
            <div className="journal-label">Dictionary Effect</div>
            <div style={{ fontWeight: 700 }}>Universal Dictionary Strengthens</div>
          </div>
        </section>

        {parseResult && (
          <section className="journal-card" style={{ display: 'grid', gap: '20px' }}>
            <div className="page-header">
              <h1>Parse Preview</h1>
              <p>These are the extracted terms and number candidates from your historical dream.</p>
            </div>

            <div
              style={{
                display: 'grid',
                gap: '16px',
                gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
              }}
            >
              <div className="journal-card-flat">
                <strong>Cash 3 / Pick 3</strong>
                <p style={{ color: 'var(--ink-light)', marginTop: '10px' }}>
                  {parseResult.cash3Numbers.length
                    ? parseResult.cash3Numbers.join(', ')
                    : 'No Cash 3 numbers found'}
                </p>
              </div>
              <div className="journal-card-flat">
                <strong>Cash 4 / Pick 4</strong>
                <p style={{ color: 'var(--ink-light)', marginTop: '10px' }}>
                  {parseResult.cash4Numbers.length
                    ? parseResult.cash4Numbers.join(', ')
                    : 'No Cash 4 numbers found'}
                </p>
              </div>
              <div className="journal-card-flat">
                <strong>Archived / Symbolic</strong>
                <p style={{ color: 'var(--ink-light)', marginTop: '10px' }}>
                  {parseResult.archivedNumbers.length ? parseResult.archivedNumbers.join(', ') : 'None'}
                </p>
              </div>
            </div>

            <div className="journal-card-flat">
              <strong>Mapped Terms</strong>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '12px' }}>
                {parseResult.termMappings.length ? (
                  parseResult.termMappings.map((mapping) => (
                    <span
                      key={mapping.term}
                      style={{
                        padding: '8px 12px',
                        borderRadius: '999px',
                        background: 'rgba(201,168,76,0.14)',
                        border: '1px solid rgba(201,168,76,0.35)',
                        color: 'var(--deep-plum)',
                        fontSize: '14px',
                      }}
                    >
                      {mapping.term}
                    </span>
                  ))
                ) : (
                  <span style={{ color: 'var(--ink-light)' }}>No mapped terms found</span>
                )}
              </div>
            </div>
          </section>
        )}

        <section className="journal-card">
          <div className="page-header">
            <h1>Recent Backtest Dreams</h1>
            <p>Your newest historical dream intakes appear here.</p>
          </div>

          {loadingRecent ? (
            <p>Loading recent backtests...</p>
          ) : recentBacktests.length ? (
            <div style={{ display: 'grid', gap: '12px', marginTop: '12px' }}>
              {recentBacktests.map((item) => (
                <div key={item.id} className="journal-card-flat">
                  <div
                    style={{
                      display: 'grid',
                      gap: '8px',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
                    }}
                  >
                    <div><div className="journal-label">Dream Date</div><div>{item.dreamDate || '—'}</div></div>
                    <div>
                      <div className="journal-label">Window</div>
                      <div>{item.activeWindowStart || '—'} → {item.activeWindowEnd || '—'}</div>
                    </div>
                    <div><div className="journal-label">Source</div><div>{item.source || '—'}</div></div>
                    <div><div className="journal-label">Cash 3</div><div>{Array.isArray(item.cash3Numbers) ? item.cash3Numbers.length : 0}</div></div>
                    <div><div className="journal-label">Cash 4</div><div>{Array.isArray(item.cash4Numbers) ? item.cash4Numbers.length : 0}</div></div>
                    <div>
                      <div className="journal-label">Status</div>
                      <div style={{
                        color: item.status === 'engine-replay-complete' ? '#6dbf8a'
                          : item.status === 'replay-complete' ? '#d4a95a'
                          : 'inherit',
                        fontWeight: item.status?.includes('complete') ? 700 : 400,
                      }}>
                        {item.status || '—'}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>No backtest dreams saved yet.</p>
          )}
        </section>
      </section>
    </main>
  );
}
